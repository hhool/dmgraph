// (c) Copyright The Code Project Open License (CPOL)
//  http://www.codeproject.com/info/cpol10.aspx
//
//  Marius Samoila 2011
//
// FILE NAME
//		GraphCollection.cpp: implementation for the CGraphCollection class
//
// CLASS NAME
//		CGraphCollection
//
// DESCRIPTION
// 
// MODIFICATIONS
//		01-Dec-2011 MSamoila created

#include "stdafx.h"
#include "DmGraph.h"
#include "GraphCollection.h"
#include "DMGraphCtrl.h"


