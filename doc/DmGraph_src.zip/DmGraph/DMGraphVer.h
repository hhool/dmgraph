#ifndef __DM_GRAPH_VER__H__
#define __DM_GRAPH_VER__H__

//this is the version of the program - stored in Version resource and displayed in about dialog

#define DM_GRAPH_VER 5,0,0,4
#define DM_GRAPH_VER_STR "5, 0, 0, 4\0"


#endif // __DM_GRAPH_VER__H__
