#ifndef __DM_GRAPH_TEST_VER__H__
#define __DM_GRAPH_TEST_VER__H__

//this is the version of the program - stored in Version resource and displayed in about dialog

#define DM_GRAPH_TEST_VER 1,0,0,2
#define DM_GRAPH_TEST_VER_STR "1, 0, 0, 2\0"


#endif // __DM_GRAPH_TEST_VER__H__
