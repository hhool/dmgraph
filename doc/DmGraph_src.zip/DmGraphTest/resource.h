//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DMGraphTest.rc
//
#define IDD_GRAPH_DATA                  101
#define IDR_MAIN                        102
#define IDI_MAIN                        103
#define IDC_CURSOR_HAND                 109
#define IDC_WEB                         214
#define IDC_COPYRIGHT_URL               215
#define IDD_ABOUTBOX                    216
#define IDC_VERSION                     227
#define IDC_LIST_POINTS                 1000
#define IDC_IMPORT                      1001
#define IDC_GENERATE                    1002
#define IDC_FUNC                        1003
#define IDC_AUTHOR                      1015
#define ID_GRAPH_INPUT_DATA             40001
#define ID_GRAPH_PROPERTIES             40002
#define ID_HELP_ABOUT_DM_GRAPH          40003
#define ID_HELP_ABOUT                   40004
#define ID_ZOOM                         40005
#define ID_PAN                          40006
#define ID_INFO                         40007
#define ID_AUTO_RANGE                   40008
#define ID_SAVE                         40009
#define ID_PRINT                        40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
